import adsk.core, adsk.fusion
import os
from ...lib import fusionAddInUtils as futil
from ... import config
import math
app = adsk.core.Application.get()
ui = app.userInterface
design = adsk.fusion.Design.cast(app.activeProduct)
rootComp = design.rootComponent
userParams = design.userParameters
sketches = rootComp.sketches


# TODO *** Specify the command identity information. ***
CMD_ID = f'{config.COMPANY_NAME}_{config.ADDIN_NAME}_cmdDialog'
CMD_NAME = 'Riblet Generator'
CMD_Description = 'A Fusion Add-in Command that generates sketches for riblets'

# Specify that the command will be promoted to the panel.
IS_PROMOTED = True

# TODO *** Define the location where the command button will be created. ***
# This is done by specifying the workspace, the tab, and the panel, and the 
# command it will be inserted beside. Not providing the command to position it
# will insert it at the end.
WORKSPACE_ID = 'FusionSolidEnvironment'
PANEL_ID = 'SolidScriptsAddinsPanel'
COMMAND_BESIDE_ID = 'ScriptsManagerCommand'

# Resource location for command icons, here we assume a sub folder in this directory named "resources".
ICON_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', '')

# Local list of event handlers used to maintain a reference so
# they are not released and garbage collected.
local_handlers = []


# Executed when add-in is run.
def start():
    # Create a command Definition.
    cmd_def = ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_Description, ICON_FOLDER)

    # Define an event handler for the command created event. It will be called when the button is clicked.
    futil.add_handler(cmd_def.commandCreated, command_created)

    # ******** Add a button into the UI so the user can run the command. ********
    # Get the target workspace the button will be created in.
    workspace = ui.workspaces.itemById(WORKSPACE_ID)

    # Get the panel the button will be created in.
    panel = workspace.toolbarPanels.itemById(PANEL_ID)

    # Create the button command control in the UI after the specified existing command.
    control = panel.controls.addCommand(cmd_def, COMMAND_BESIDE_ID, False)

    # Specify if the command is promoted to the main toolbar. 
    control.isPromoted = IS_PROMOTED


# Executed when add-in is stopped.
def stop():
    # Get the various UI elements for this command
    workspace = ui.workspaces.itemById(WORKSPACE_ID)
    panel = workspace.toolbarPanels.itemById(PANEL_ID)
    command_control = panel.controls.itemById(CMD_ID)
    command_definition = ui.commandDefinitions.itemById(CMD_ID)

    # Delete the button command control
    if command_control:
        command_control.deleteMe()

    # Delete the command definition
    if command_definition:
        command_definition.deleteMe()


# Function that is called when a user clicks the corresponding button in the UI.
# This defines the contents of the command dialog and connects to the command related events.
def command_created(args: adsk.core.CommandCreatedEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Created Event')

    # https://help.autodesk.com/view/fusion360/ENU/?contextId=CommandInputs
    inputs = args.command.commandInputs
    inputs.addIntegerSpinnerCommandInput('num_riblets', 'Number of Riblets', 1, 30, 1, 3)

    # TODO Connect to the events that are needed by this command.
    futil.add_handler(args.command.execute, command_execute, local_handlers=local_handlers)
    futil.add_handler(args.command.inputChanged, command_input_changed, local_handlers=local_handlers)
    futil.add_handler(args.command.destroy, command_destroy, local_handlers=local_handlers)

# This event handler is called when the user clicks the OK button in the command dialog or 
# is immediately called after the created event not command inputs were created for the dialog.
def command_execute(args: adsk.core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Execute Event')

    # Get a reference to your command's inputs.
    inputs = args.command.commandInputs
    num_riblets_spinner: adsk.core.IntegerSpinnerCommandInput = inputs.itemById('num_riblets')
    num_riblets = num_riblets_spinner.value
    length = userParams.itemByName('CW').value * 0.75
    height = userParams.itemByName('Height').value
    depth = userParams.itemByName('CL').value
    riblet_depth = userParams.itemByName('RD').value

    # ******************************** Your code here ********************************
    sketch = sketches.add(rootComp.xZConstructionPlane)
    splines = sketch.sketchCurves.sketchFittedSplines
    constraints = sketch.geometricConstraints
    sketchDimensions = sketch.sketchDimensions
    sketchLines = sketch.sketchCurves.sketchLines
    

    for i in range(num_riblets):
        points = adsk.core.ObjectCollection.create()

        # Define the points the spline with fit through.
        points.add(adsk.core.Point3D.create(0, -height, 0))
        points.add(adsk.core.Point3D.create(-length/(2*num_riblets), -height-0.1, 0))
        points.add(adsk.core.Point3D.create(-length/num_riblets, -height-0.2, 0))
        
        spline = splines.add(points)
        fitPoints = spline.fitPoints

        fitPoint1 = fitPoints.item(1)
        line = spline.activateTangentHandle(fitPoint1)            
        constraints.addHorizontal(line)
        sketchDimension = sketchDimensions.addDistanceDimension(line.startSketchPoint, line.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, line.endSketchPoint.geometry)
        # TODO: might use curvature handle here
        sketchDimension.parameter.expression = '1.5 mm'

        fitPoint0 = fitPoints.item(0)
        line = spline.activateTangentHandle(fitPoint0)            
        constraints.addHorizontal(line)
        sketchDimension = sketchDimensions.addDistanceDimension(line.startSketchPoint, line.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, line.endSketchPoint.geometry)
        sketchDimension.parameter.expression = '1 mm'

        fitPoint2 = fitPoints.item(2)
        line = spline.activateTangentHandle(fitPoint2)
        constraints.addHorizontal(line)
        sketchDimension = sketchDimensions.addDistanceDimension(line.startSketchPoint, line.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, line.endSketchPoint.geometry)
        sketchDimension.parameter.expression = '1 mm'

        sketchDimension = sketchDimensions.addDistanceDimension(fitPoint0, fitPoint2, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, fitPoint0.geometry)
        sketchDimension.parameter.expression = f'CW*0.75/{num_riblets}'

        sketchDimension = sketchDimensions.addDistanceDimension(fitPoint0, fitPoint1, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, fitPoint1.geometry)
        sketchDimension.parameter.expression = f'{(i+1)/(num_riblets+1)}*CW*0.75/{num_riblets}'
        
        if i == 0:
            first_spline = spline
        else:
            constraints.addCoincident(spline.startSketchPoint, prev_spline.endSketchPoint)
        
        h=5
        displacementFull = -h*(4)*((i+1)/num_riblets)*((i+1)/num_riblets-1)
        displacementHalf = -h*(4)*((i+0.5)/num_riblets)*((i+0.5)/num_riblets-1)

        sketchDimension = sketchDimensions.addDistanceDimension(first_spline.fitPoints.item(0), fitPoint2, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, fitPoint2.geometry)
        sketchDimension.parameter.expression = f'{displacementFull} mm'

        sketchDimension = sketchDimensions.addDistanceDimension(first_spline.fitPoints.item(0), fitPoint1, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, fitPoint1.geometry)
        sketchDimension.parameter.expression = f'{displacementHalf} mm - RD'
        prev_spline = spline
    
    horizontalConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    constraints.addCoincident(horizontalConstructionLine.startSketchPoint, first_spline.startSketchPoint)
    constraints.addCoincident(horizontalConstructionLine.endSketchPoint, spline.endSketchPoint)
    horizontalConstructionLine.isConstruction = True

    verticalConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    constraints.addMidPoint(verticalConstructionLine.startSketchPoint, horizontalConstructionLine)
    constraints.addCoincident(verticalConstructionLine.endSketchPoint, sketch.originPoint)
    constraints.addVertical(verticalConstructionLine)
    verticalConstructionLine.isConstruction = True

    sketchDimension = sketchDimensions.addDistanceDimension(verticalConstructionLine.startSketchPoint, verticalConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, verticalConstructionLine.endSketchPoint.geometry)
    sketchDimension.parameter.expression = 'Height'


    sketch = sketches.add(rootComp.yZConstructionPlane)
    splines = sketch.sketchCurves.sketchFittedSplines
    constraints = sketch.geometricConstraints
    sketchDimensions = sketch.sketchDimensions
    sketchLines = sketch.sketchCurves.sketchLines

    constructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(1, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    constraints.addCoincident(constructionLine.startSketchPoint, sketch.originPoint)
    constraints.addHorizontal(constructionLine)
    constructionLine.isConstruction = True

    sketchDimension = sketchDimensions.addDistanceDimension(constructionLine.startSketchPoint, constructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, constructionLine.endSketchPoint.geometry)
    sketchDimension.parameter.expression = 'Height' # This will change in the for loop

    for i in range(num_riblets):
        futil.log(f'{i}')
        points = adsk.core.ObjectCollection.create()

        # Define the points the spline with fit through.
        points.add(adsk.core.Point3D.create(-height, -1, i))
        points.add(adsk.core.Point3D.create(-height-riblet_depth/2, depth/10, i))
        points.add(adsk.core.Point3D.create(-height-riblet_depth/2, depth, i))

        spline = splines.add(points)
        fitPoints = spline.fitPoints

        fitPoint0 = fitPoints.item(0)
        line = spline.activateTangentHandle(fitPoint0)
        constraints.addHorizontal(line)
        sketchDimension = sketchDimensions.addDistanceDimension(line.startSketchPoint, line.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, line.endSketchPoint.geometry)
        sketchDimension.parameter.expression = '5 mm'
        
        horizontalConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
        constraints.addCoincident(horizontalConstructionLine.startSketchPoint, fitPoint0)
        constraints.addVertical(horizontalConstructionLine)
        horizontalConstructionLine.isConstruction = True

        if i != 0:
            offsetConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, -10), adsk.core.Point3D.create(0, 0, 0))
            constraints.addPerpendicular(offsetConstructionLine, horizontalConstructionLine)
            constraints.addPerpendicular(offsetConstructionLine, constructionLine)
            constraints.addCoincident(offsetConstructionLine.endSketchPoint, horizontalConstructionLine)
            constraints.addCoincident(offsetConstructionLine.startSketchPoint, constructionLine.endSketchPoint)
            offsetConstructionLine.isConstruction = True

            sketchDimension = sketchDimensions.addDistanceDimension(offsetConstructionLine.startSketchPoint, offsetConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.AlignedDimensionOrientation, offsetConstructionLine.endSketchPoint.geometry)
            sketchDimension.parameter.expression = f'{i*10} mm' # This will change in the for loop
        else:
            constraints.addCoincident(constructionLine.endSketchPoint, horizontalConstructionLine)
            offsetConstructionLine = constructionLine

        sketchDimension = sketchDimensions.addDistanceDimension(fitPoint0, offsetConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.AlignedDimensionOrientation, constructionLine.endSketchPoint.geometry)
        sketchDimension.parameter.expression = '10 mm'

        fitPoint1 = fitPoints.item(1)
        line = spline.activateTangentHandle(fitPoint1)
        sketchDimension = sketchDimensions.addDistanceDimension(fitPoint0, fitPoint1, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, fitPoint1.geometry)
        sketchDimension.parameter.expression = 'CL/10'
        sketchDimension = sketchDimensions.addDistanceDimension(line.startSketchPoint, line.endSketchPoint, adsk.fusion.DimensionOrientations.AlignedDimensionOrientation, line.endSketchPoint.geometry)
        sketchDimension.parameter.expression = '6 mm'         

        verticalConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
        constraints.addCoincident(verticalConstructionLine.startSketchPoint, horizontalConstructionLine)
        constraints.addCoincident(verticalConstructionLine.endSketchPoint, fitPoint1)
        constraints.addHorizontal(verticalConstructionLine)
        verticalConstructionLine.isConstruction = True
        sketchDimension = sketchDimensions.addDistanceDimension(verticalConstructionLine.startSketchPoint, verticalConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, verticalConstructionLine.endSketchPoint.geometry)
        sketchDimension.parameter.expression = 'RD/2'
        sketchAngle = sketchDimensions.addAngularDimension(line, verticalConstructionLine, verticalConstructionLine.endSketchPoint.geometry)
        sketchAngle.value = 75 * math.pi/180

        fitPoint2 = fitPoints.item(2)
        line = spline.activateTangentHandle(fitPoint2)
        sketchDimension = sketchDimensions.addDistanceDimension(fitPoint0, fitPoint2, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, fitPoint2.geometry)
        sketchDimension.parameter.expression = 'CL'
        sketchDimension = sketchDimensions.addDistanceDimension(line.startSketchPoint, line.endSketchPoint, adsk.fusion.DimensionOrientations.AlignedDimensionOrientation, line.endSketchPoint.geometry)
        sketchDimension.parameter.expression = '18 mm'

        verticalConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
        constraints.addCoincident(verticalConstructionLine.startSketchPoint, horizontalConstructionLine.endSketchPoint)
        constraints.addCoincident(verticalConstructionLine.endSketchPoint, fitPoint2)
        constraints.addHorizontal(verticalConstructionLine)
        verticalConstructionLine.isConstruction = True
        sketchDimension = sketchDimensions.addDistanceDimension(verticalConstructionLine.startSketchPoint, verticalConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, verticalConstructionLine.endSketchPoint.geometry)
        sketchDimension.parameter.expression = 'RD'
        sketchAngle = sketchDimensions.addAngularDimension(line, verticalConstructionLine, verticalConstructionLine.endSketchPoint.geometry)
        sketchAngle.value = 85 * math.pi/180

    planes = rootComp.constructionPlanes
    sketch = sketches.add(planes.itemByName('CrownPlane'))
    sketchLines = sketch.sketchCurves.sketchLines
    conicCurves = sketch.sketchCurves.sketchConicCurves
    constraints = sketch.geometricConstraints
    sketchDimensions = sketch.sketchDimensions
    splines = sketch.sketchCurves.sketchFittedSplines

    points = adsk.core.ObjectCollection.create()

    # Define the points the spline with fit through.
    points.add(adsk.core.Point3D.create(-3, 2.5, 0))
    points.add(adsk.core.Point3D.create(-4, -1, 0))
    points.add(adsk.core.Point3D.create(0, -4.5, 0))
    points.add(adsk.core.Point3D.create(4, -1, 0))
    points.add(adsk.core.Point3D.create(3, 2.5, 0))

    
    spline1 = splines.add(points)
    fitPoints1 = spline1.fitPoints

    # Get the second fit point
    fitPoint1 = fitPoints1.item(0)
    line1 = spline1.activateTangentHandle(fitPoint1)            
    constraints.addHorizontal(line1)
    sketchDimension = sketchDimensions.addDistanceDimension(line1.startSketchPoint, line1.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, line1.endSketchPoint.geometry)
    sketchDimension.parameter.expression = '5 mm'
    fitPoint2 = fitPoints1.item(4)
    line2 = spline1.activateTangentHandle(fitPoint2)
    constraints.addHorizontal(line2)
    constraints.addEqual(line1, line2)

    topConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    constraints.addCoincident(topConstructionLine.startSketchPoint, fitPoint1)
    constraints.addCoincident(topConstructionLine.endSketchPoint, fitPoint2)
    topConstructionLine.isConstruction = True
    sketchDimension = sketchDimensions.addDistanceDimension(topConstructionLine.startSketchPoint, topConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, topConstructionLine.endSketchPoint.geometry)
    sketchDimension.parameter.expression = 'CW * 0.75'

    fitPoint1 = fitPoints1.item(1)
    line1 = spline1.activateTangentHandle(fitPoint1)
    constraints.addVertical(line1)
    sketchDimension = sketchDimensions.addDistanceDimension(line1.startSketchPoint, line1.endSketchPoint, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, line1.endSketchPoint.geometry)
    sketchDimension.parameter.expression = '15 mm'
    fitPoint2 = fitPoints1.item(3)
    line2 = spline1.activateTangentHandle(fitPoint2)
    constraints.addVertical(line2)
    constraints.addEqual(line1, line2)

    constructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    constraints.addCoincident(constructionLine.startSketchPoint, fitPoint1)
    constraints.addCoincident(constructionLine.endSketchPoint, fitPoint2)
    constructionLine.isConstruction = True
    sketchDimension = sketchDimensions.addDistanceDimension(constructionLine.startSketchPoint, constructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, constructionLine.endSketchPoint.geometry)
    sketchDimension.parameter.expression = 'CW'
    
    fitPoint = fitPoints1.item(2)
    line = spline1.activateTangentHandle(fitPoint)
    constraints.addHorizontal(line)
    sketchDimension = sketchDimensions.addDistanceDimension(line.startSketchPoint, line.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, line.endSketchPoint.geometry)
    sketchDimension.parameter.expression = '20 mm'

    verticalConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    constraints.addVertical(verticalConstructionLine)
    constraints.addMidPoint(verticalConstructionLine.startSketchPoint, constructionLine)
    constraints.addCoincident(verticalConstructionLine.endSketchPoint, fitPoint)
    verticalConstructionLine.isConstruction = True
    sketchDimension = sketchDimensions.addDistanceDimension(verticalConstructionLine.startSketchPoint, verticalConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, verticalConstructionLine.endSketchPoint.geometry)
    sketchDimension.parameter.expression = 'CL/2'
    constraints.addSymmetry(fitPoints1.item(0), fitPoints1.item(4), verticalConstructionLine)
    constraints.addSymmetry(fitPoints1.item(1), fitPoints1.item(3), verticalConstructionLine)

    sketchDimension = sketchDimensions.addOffsetDimension(constructionLine, topConstructionLine, constructionLine.startSketchPoint.geometry)
    sketchDimension.parameter.expression = 'CL/2'

    verticalConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    constraints.addVertical(verticalConstructionLine)
    constraints.addCoincident(verticalConstructionLine.startSketchPoint, sketch.originPoint)
    constraints.addMidPoint(verticalConstructionLine.endSketchPoint, constructionLine)
    verticalConstructionLine.isConstruction = True
    sketchDimension = sketchDimensions.addDistanceDimension(verticalConstructionLine.startSketchPoint, verticalConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, verticalConstructionLine.endSketchPoint.geometry)
    sketchDimension.parameter.expression = '10 mm'

    points = adsk.core.ObjectCollection.create()

    # Define the points the spline with fit through.
    points.add(adsk.core.Point3D.create(-1, 2.5, 0))
    points.add(adsk.core.Point3D.create(0, 10, 0))
    points.add(adsk.core.Point3D.create(1, 2.5, 0))

    spline2 = splines.add(points)
    spline2.isConstruction = True
    fitPoints2 = spline2.fitPoints

    fitPoint1 = fitPoints2.item(0)
    line1 = spline2.activateTangentHandle(fitPoint1)
    constraints.addCoincident(fitPoint1, fitPoints1.item(0))       
    constraints.addVertical(line1)
    fitPoint2 = fitPoints2.item(2)
    line2 = spline2.activateTangentHandle(fitPoint2)
    constraints.addCoincident(fitPoint2, fitPoints1.item(4)) 
    constraints.addVertical(line2)
    constraints.addEqual(line1, line2)
    sketchDimension = sketchDimensions.addDistanceDimension(line1.startSketchPoint, line1.endSketchPoint, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, line1.endSketchPoint.geometry)
    sketchDimension.parameter.expression = '10 mm'

    fitPoint = fitPoints2.item(1)
    line = spline2.activateTangentHandle(fitPoint)            
    constraints.addHorizontal(line)
    sketchDimension = sketchDimensions.addDistanceDimension(line.startSketchPoint, line.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, line.endSketchPoint.geometry)
    sketchDimension.parameter.expression = '15 mm'

    verticalConstructionLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    constraints.addVertical(verticalConstructionLine)
    constraints.addCoincident(verticalConstructionLine.startSketchPoint, fitPoint)
    constraints.addMidPoint(verticalConstructionLine.endSketchPoint, topConstructionLine)
    verticalConstructionLine.isConstruction = True
    sketchDimension = sketchDimensions.addDistanceDimension(verticalConstructionLine.startSketchPoint, verticalConstructionLine.endSketchPoint, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, verticalConstructionLine.endSketchPoint.geometry)
    sketchDimension.parameter.expression = 'CL/5'
    
    for i in range(num_riblets):
        conicCurve = conicCurves.add(
            adsk.core.Point3D.create(0, 6.7, 0),
            adsk.core.Point3D.create(length, 6.7, 0), 
            adsk.core.Point3D.create(0, 0, 0),
            0.75
        )

        if i == 0:
            constraints.addCoincident(conicCurve.startSketchPoint, spline2.startSketchPoint)
        else:
            pass
            constraints.addCoincident(conicCurve.startSketchPoint, prev_conicCurve.endSketchPoint)

        constraints.addCoincident(conicCurve.endSketchPoint, spline2)
        pointLine = sketchLines.addByTwoPoints(conicCurve.startSketchPoint, conicCurve.endSketchPoint)
        pointLine.isConstruction = True

        verticalLine = sketchLines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, 0, 0))
        constraints.addMidPoint(verticalLine.startSketchPoint, pointLine)
        constraints.addVertical(verticalLine)
        constraints.addCoincident(verticalLine.endSketchPoint, conicCurve.apexSketchPoint)
        verticalLine.isConstruction = True

        sketchDimension = sketchDimensions.addDistanceDimension(verticalLine.startSketchPoint, verticalLine.endSketchPoint, adsk.fusion.DimensionOrientations.VerticalDimensionOrientation, verticalLine.endSketchPoint.geometry)
        sketchDimension.parameter.expression = 'RT'
        sketchDimension = sketchDimensions.addDistanceDimension(pointLine.startSketchPoint, pointLine.endSketchPoint, adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation, pointLine.startSketchPoint.geometry)
        sketchDimension.parameter.expression = f'CW*0.75/{num_riblets}'
        prev_conicCurve = conicCurve

# This event handler is called when the user changes anything in the command dialog
# allowing you to modify values of other inputs based on that change.
def command_input_changed(args: adsk.core.InputChangedEventArgs):
    changed_input = args.input
    inputs = args.inputs

    # General logging for debug.
    futil.log(f'{CMD_NAME} Input Changed Event fired from a change to {changed_input.id}')
        

# This event handler is called when the command terminates.
def command_destroy(args: adsk.core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Destroy Event')

    global local_handlers
    local_handlers = []
    